# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['qif2json']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'qif2json',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Miyano',
    'author_email': 'dr000w@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
