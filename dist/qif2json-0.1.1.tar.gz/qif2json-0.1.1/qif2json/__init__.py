__version__ = '0.1.1'

from qif2json import convert_qif
