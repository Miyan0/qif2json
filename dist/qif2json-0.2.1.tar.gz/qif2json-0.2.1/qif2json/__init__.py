__version__ = '0.2.1'

from qif2json.qif2json import convert_qif
